let soundEnabled = true;

function toggleSound() {
  soundEnabled = !soundEnabled;
  alert(`Sound ${soundEnabled ? 'enabled' : 'muted'}`);
}

function playSound(file) {
  if (!soundEnabled) return;
  const audio = new Audio(file);
  audio.play();
}

function showMessage(text) {
  const message = document.getElementById('message');
  message.textContent = text;
  message.className = 'fade-in';
  setTimeout(() => {
    message.className = 'fade-out';
  }, 1500);
}

function changeText() {
  const title = document.getElementById('title');
  title.textContent = "You've changed the heading text!";
}

function toggleStyle() {
  const description = document.getElementById('description');
  const isBlue = description.style.color === 'blue';
  description.style.color = isBlue ? 'black' : 'blue';
  description.style.fontWeight = isBlue ? 'normal' : 'bold';
}

function addItem() {
  const list = document.getElementById('itemList');
  const newItem = document.createElement('li');
  const itemCount = list.children.length + 1;
  newItem.textContent = `B${itemCount}`;
  newItem.classList.add('fade-in');
  list.appendChild(newItem);
  showMessage("Item added!");
  playSound('sounds/add.mp3');
}

function removeItem() {
  const list = document.getElementById('itemList');
  if (list.lastElementChild) {
    const confirmed = confirm("Are you sure you want to remove the last item?");
    if (!confirmed) return;
    const lastItem = list.lastElementChild;
    lastItem.classList.add('fade-out');
    setTimeout(() => {
      list.removeChild(lastItem);
      showMessage("Item removed!");
      playSound('sounds/remove.mp3');
    }, 300);
  }
}
